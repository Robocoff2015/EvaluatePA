﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EvaluatePa.Models
{
    public class EvaluateWork
    {

        public string item { get; set; }
        public string Name { get; set; }
        public string Date_Time { get; set; }
        public string status { get; set; }
        public string ExpertAmount { get; set; }
    }
}
