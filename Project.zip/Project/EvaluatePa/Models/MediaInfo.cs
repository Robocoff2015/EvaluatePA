﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EvaluatePa.Models
{
    public class MediaInfo
    {



        public string ID { get; set; }
        public string Date { get; set; }
        public string Message { get; set; }
        public string Information { get; set; }
        public string Information2 { get; set; }
        public string user_id { get; set; }
        public string Status { get; set; }
        public string UpdateDate { get; set; }
        public string ExpiredDate { get; set; }


    }
}